import os
from flask import Flask, render_template, redirect, url_for, flash, request
from database import db
from flask_migrate import Migrate
from models import Cita
from flask_wtf import FlaskForm
from wtforms import StringField, SelectField, SubmitField, BooleanField, EmailField, SelectMultipleField, widgets
from wtforms.validators import DataRequired, Email
from forms import RegistroCitaForm


app = Flask(__name__)

# Inicializar db con la app
db.init_app(app)
migrate = Migrate(app, db) #2. Configurar

from models import Cita  # <--- Importar aquí es clave

# Crear tabla
with app.app_context():
    db.create_all()
    print("Tablas creadas en PostgreSQL con éxito")



class MultiCheckboxField(SelectMultipleField):
    widget = widgets.ListWidget(prefix_label=False)
    option_widget = widgets.CheckboxInput()


# --- RUTAS ---

def calcular_costo(especie, servicios_seleccionados):
    # Diccionario de precios (puedes ajustar los montos según tu .ods)
    precios_perro = {
        'v_multiple_desp_externa': {'normal': 570.0, 'promo': 513.0},
        'v_multiple_desp_interna': {'normal': 400.0, 'promo': 360.0},
        'v_rabia_desp_interna_externa': {'normal': 650.0, 'promo': 585.0},
        'desp_interna_externa': {'normal': 600.0, 'promo': 540.0},
        'v_multiple_y_rabia': {'normal': 400.0, 'promo': 360.0},
        'v_cuadruple_multiple_y_rabia': {'normal': 750.0, 'promo': 675.0},
        'v_cuadruple_multiple_rabia_desp_int_ext': {'normal': 950.0, 'promo': 855.0},
        'v_bordetella': {'normal': 300.0, 'promo': 270.0},
        'v_antirrabica': {'normal': 250.0, 'promo': 225.0}, # Ajustado de 200 a 250
        'v_sextuple': {'normal': 450.0, 'promo': 405.0},
        'v_cuadruple': {'normal': 400.0, 'promo': 360.0},
        'desp_int_menor_10kg': {'normal': 240.0, 'promo': 216.0},
        'desp_int_10kg_20kg': {'normal': 280.0, 'promo': 252.0},
        'desp_int_mayor_20kg': {'normal': 300.0, 'promo': 270.0},
        'desp_ext_menor_10kg': {'normal': 200.0, 'promo': 180.0},
        'desp_ext_10kg_20kg': {'normal': 250.0, 'promo': 225.0},
        'desp_ext_mayor_20kg': {'normal': 300.0, 'promo': 270.0}
    }

    precios_gato = {
        'v_cuadruple_desparacitacion_completa': {
            'posterior': 560.0,
            'promo_9_11': 504.0
        },
        'prueba_v_leucemia': {
            'posterior': 890.0,
            'promo_9_11': 801.0
        },
        'v_rabia_desparacitacion_completa': {
            'posterior': 450.0,
            'promo_9_11': 405.0
        },
        'desparacitacion_interna_externa': {
            'posterior': 400.0,
            'promo_9_11': 360.0
        },
        'v_cuadruple_felina': {
            'posterior': 350.0,
            'promo_9_11': 315.0
        },
        'desparacitacion_interna': {
            'posterior': 300.0,
            'promo_9_11': 270.0
        },
        'v_antirrabica_gato': {
            'posterior': 250.0,
            'promo_9_11': 225.0
        }
    }

    total = 0.0
    lista_precios = precios_perro if especie == 'Perro' else precios_gato

    for s in servicios_seleccionados:
        total += lista_precios.get(s, 0.0)

    return total



if __name__ == '__main__':
    #app.run(host="0.0.0.0", port=8000, debug=False)
    app.run(port=8000, debug=True)
