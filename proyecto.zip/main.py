def main():
    print("Hello from vet-forms!")


if __name__ == "__main__":
    main()
