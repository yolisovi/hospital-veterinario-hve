import os
#parametros del sistema
class Config(object): #hereda de clase padre object/ config de producción
    SECRET_KEY = os.environ.get('SECRET_KEY', 'mi_llave_secreta_123') #SECRTE SE VUELVE CONSTANTE, si no encuentra 'SECRET_KEY en la RAM usa 'mi_llave_secreta_123'
    SQLALCHEMY_TRACK_MODIFICATIONS = False

class Produccion(Config):
    # Si estamos en Render, usará DATABASE_URL. Si no, usará SQLite local.
    uri = os.environ.get('DATABASE_URL', 'postgresql://')
    SQLALCHEMY_DATABASE_URI = uri

class Desarrollo(Config): #producción
    uri = os.environ.get('DATABASE_URL', 'sqlite:///camp_vacu_vet.db') #se cambia a postgresSQL
    SQLALCHEMY_DATABASE_URI = uri
