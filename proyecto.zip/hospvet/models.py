from hospvet import db #hospvet tiene el archicov que arranca
from datetime import datetime
   # --- MODELO ---
class Cita(db.Model):
    __tablename__ = 'citas'
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(100), nullable=False, unique=True)
    nombre = db.Column(db.String(50), nullable=False)
    apellido1 = db.Column(db.String(50), nullable=True)
    apellido2 = db.Column(db.String(50), nullable=True)
    telefono = db.Column(db.String(20), nullable=False)
    mascota = db.Column(db.String(100), nullable=False)
    edad = db.Column(db.Integer)
    especie = db.Column(db.String(20), nullable=False)

    # Logística de la Campaña
    dia_semana = db.Column(db.String(20), nullable=False) # Lunes, Martes, etc.
    bloque_horario = db.Column(db.String(20), nullable=False) # Mañana o Tarde
    servicios = db.Column(db.String(500), nullable=False)
    costo_total = db.Column(db.Float, default=0.0)
    fecha_registro = db.Column(db.DateTime, default=datetime.utcnow())
