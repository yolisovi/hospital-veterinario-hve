import os
from flask import Blueprint, render_template, url_for, request, flash, redirect
from hospvet import db #puede traer el db porque init le da valores iniciales al paquete, no necesita invocarse
from hospvet.models import Cita #permite acceder a la clase que apunta a la clase de datos
from hospvet.campañas.vacunacion.forms import RegistroCitaForm


campvacuna = Blueprint('campvacuna', __name__) #que genere un modulo que se llame campvacun ay que apunte a la aplicación

@campvacuna.route('/', methods=['GET', 'POST'])
def campvacini():
    # --- Bloque de Mantenimiento ---
    mantenimiento = os.environ.get('MODO_MANTENIMIENTO', 'ON').strip()
    acceso_secreto = request.args.get('acceso', '')
    if mantenimiento == 'ON' and acceso_secreto != "hve2026":
        return render_template('mantenimiento.html'), 503

    form = RegistroCitaForm()

    if form.validate_on_submit():
        # 1. Definir límites según tus archivos de "Número de Atenciones"
        limite = 25 if form.especie.data == 'Perro' else 10

        # 2. Verificar cupos en la base de datos
        citas_existentes = Cita.query.filter_by(
            especie=form.especie.data,
            dia_semana=form.dia_semana.data,
            bloque_horario=form.bloque_horario.data
        ).count()

        if citas_existentes >= limite:
            flash(f'Lo sentimos, el turno de la {form.bloque_horario.data} para {form.especie.data}s el {form.dia_semana.data} está lleno.')
            return redirect(url_for('index', acceso='hve2026'))

        # 3. Lógica de servicios y costos (Basado en tus tablas de costos)
        # LÓGICA DE COSTOS ACTUALIZADA
        peso_int = None
        peso_ext = None

        if form.especie.data == 'Perro':
            servicios_sel = form.servicios_perro.data
            peso_int = form.rango_peso_perro_interno.data
            peso_ext = form.rango_peso_perro_externo.data
        else:
            servicios_sel = form.servicios_gato.data

        costo_estimado = calcular_costo(form.especie.data, servicios_sel, peso_int, peso_ext)

        nueva_cita = Cita(
            email=form.email.data,
            nombre=form.nombre.data,
            apellido1=form.apellido1.data,
            apellido2=form.apellido2.data,
            telefono=form.telefono.data,
            mascota=form.mascota.data,
            edad=form.edad.data,
            especie=form.especie.data,
            dia_semana=form.dia_semana.data,
            bloque_horario=form.bloque_horario.data,
            servicios=", ".join(servicios_sel),
            costo_total=costo_estimado
        )

        db.session.add(nueva_cita)
        db.session.commit()

        flash(f'¡Cita registrada! Costo estimado: ${costo_estimado}')
        return redirect(url_for('campvacuna.campvacini', acceso='hve2026'))

    return render_template('index.html', form=form)


def calcular_costo(especie, servicios_seleccionados, peso_interno=None, peso_externo=None):
    # Diccionario de precios (puedes ajustar los montos según tu .ods)
    precios_perro = {
        'v_multiple_desp_externa': {'normal': 570.0, 'promo': 513.0},
        'v_multiple_desp_interna': {'normal': 400.0, 'promo': 360.0},
        'v_rabia_desp_interna_externa': {'normal': 650.0, 'promo': 585.0},
        'desp_interna_externa': {'normal': 600.0, 'promo': 540.0},
        'v_multiple_y_rabia': {'normal': 400.0, 'promo': 360.0},
        'v_cuadruple_multiple_y_rabia': {'normal': 750.0, 'promo': 675.0},
        'v_cuadruple_multiple_rabia_desp_int_ext': {'normal': 950.0, 'promo': 855.0},
        'v_bordetella': {'normal': 300.0, 'promo': 270.0},
        'v_antirrabica': {'normal': 250.0, 'promo': 225.0}, # Ajustado de 200 a 250
        'v_sextuple': {'normal': 450.0, 'promo': 405.0},
        'v_cuadruple': {'normal': 400.0, 'promo': 360.0},
        'desp_int_menor_10kg': {'normal': 240.0, 'promo': 216.0},
        'desp_int_10kg_20kg': {'normal': 280.0, 'promo': 252.0},
        'desp_int_mayor_20kg': {'normal': 300.0, 'promo': 270.0},
        'desp_ext_menor_10kg': {'normal': 200.0, 'promo': 180.0},
        'desp_ext_10kg_20kg': {'normal': 250.0, 'promo': 225.0},
        'desp_ext_mayor_20kg': {'normal': 300.0, 'promo': 270.0}
    }

    precios_gato = {
        'v_cuadruple_desparacitacion_completa': {
            'posterior': 560.0,
            'promo_9_11': 504.0
        },
        'prueba_v_leucemia': {
            'posterior': 890.0,
            'promo_9_11': 801.0
        },
        'v_rabia_desparacitacion_completa': {
            'posterior': 450.0,
            'promo_9_11': 405.0
        },
        'desparacitacion_interna_externa': {
            'posterior': 400.0,
            'promo_9_11': 360.0
        },
        'v_cuadruple_felina': {
            'posterior': 350.0,
            'promo_9_11': 315.0
        },
        'desparacitacion_interna': {
            'posterior': 300.0,
            'promo_9_11': 270.0
        },
        'v_antirrabica_gato': {
            'posterior': 250.0,
            'promo_9_11': 225.0
        }
    }

    total = 0.0

    if especie == 'Perro':
        # 1. Sumar servicios/vacunas seleccionados del checkbox
        for s in servicios_seleccionados:
            total += precios_perro.get(s, {}).get('normal', 0.0)

        # 2. Sumar costo por peso INTERNO (Radio Button 1)
        if peso_interno:
            # llave resultante: 'desp_int_menor_10kg', etc.
            llave_int = f"desp_int_{peso_interno}"
            total += precios_perro.get(llave_int, {}).get('normal', 0.0)

        # 3. Sumar costo por peso EXTERNO (Radio Button 2)
        if peso_externo:
            # llave resultante: 'desp_ext_menor_10kg', etc.
            llave_ext = f"desp_ext_{peso_externo}"
            total += precios_perro.get(llave_ext, {}).get('normal', 0.0)

    else:
        # Lógica para Gatos
        for s in servicios_seleccionados:
            total += precios_gato.get(s, {}).get('posterior', 0.0)

    return total
